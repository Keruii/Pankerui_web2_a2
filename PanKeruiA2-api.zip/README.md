# PROG2002 A2 — API and database files

This archive contains the read-only Express API under `api/`, its MySQL connection-pool configuration, event photo mapping, dependency manifests, and SQL schema/sample data.

Extract this archive and `PanKeruiA2-clientside.zip` into the same project directory. Then:

1. Install Node.js and MySQL Server.
2. Import `api/charityevents_db.sql` using MySQL Workbench. **This seed script drops and recreates the project tables.**
3. Copy `api/.env.example` to `api/.env` if your local MySQL settings differ. The defaults expect MySQL on `localhost:3306` and a local `root` account with a blank password.
4. Run `cd api`, `npm install`, then `npm start`.
5. Open `http://localhost:3000/`.

## Routes

- `GET /api/home/events`
- `GET /api/categories`
- `GET /api/events/search?date=YYYY-MM-DD&location_suburb=Brisbane&category_id=1`
- `GET /api/events/:event_id`

The API only reads data; registration and donation processing are not implemented. Event photos are hosted remotely and require an internet connection.