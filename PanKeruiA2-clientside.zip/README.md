# PROG2002 A2 — Client-side code

This archive contains the Community Hope Australia event website under `client/`: the home page, event search page, event detail page, CSS, and browser-side JavaScript.

Extract this archive and the companion `PanKeruiA2-api.zip` into the same project directory. The API serves this `client/` folder at `http://localhost:3000/`; the client requests JSON from `http://localhost:3000/api`.

The event photographs are hosted remotely, so viewing them requires an internet connection.